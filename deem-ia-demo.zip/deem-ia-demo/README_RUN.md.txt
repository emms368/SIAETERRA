#DEEM-IA — Detection and Mitigation Strategies with AI

**DEEM-IA** is a demo application developed for a hackathon.  
It simulates **asteroid detection in images** using computer vision and computes basic physical properties (mass, impact energy, risk level).  
Based on these properties, it proposes **mitigation strategies** (e.g., monitoring, kinetic impact, nearby nuclear explosion, gravity tractor).  

The goal is **educational and demonstrative**, not scientific, and it is designed to be easily extensible to real data (NASA NEO API, trained YOLO models).

---

##Technologies Used

- **Python 3.10 (Miniconda)** — reproducible environment.  
- **Streamlit** — interactive web interface.  
- **OpenCV** — computer vision (simulated asteroid detection).  
- **NumPy** — physical and numerical calculations.  
- **Pillow** — image handling.  
- **Pandas + PyDeck** — tables and map visualization support.  

---

##Project Structure
deem-ia-demo/
├── app.py # Main Streamlit interface
├── detection.py # Simulated asteroid detection (OpenCV)
├── physics.py # Physical calculations and mitigation suggestions
├── utils.py # Helper functions
├── generate_demo_images.py # Demo image generator
├── requirements.txt # Project dependencies
└── README.md # Documentation


---

##Installation

### 1. Prerequisites
- Install **Miniconda**:  
  https://docs.conda.io/en/latest/miniconda.html  
- Git (optional, if cloning from GitHub).  

### 2. Create a Miniconda environment
```bash
conda create -n deem-ia python=3.10.11 -y
conda activate deem-ia

### 3. Install dependencies
pip install -r requirements.txt

### 4. (Optional) Generate demo images
python generate_demo_images.py

### 5. Run the application
streamlit run app.py

The application will be available at:
http://localhost:8501
