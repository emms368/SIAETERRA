1) Crear entorno:
   conda create -n deem-ia python=3.10.11 -y
   conda activate deem-ia

2) Instalar dependencias:
   pip install -r requirements.txt

3) Generar imágenes demo (opcional):
   python generate_demo_images.py

4) Ejecutar la app:
   streamlit run app.py

5) Abrir http://localhost:8501 en tu navegador si Streamlit no lo abre automáticamente.
