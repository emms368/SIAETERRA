import cv2
import numpy as np
import os

def generar_imagen_demo(nombre="demo.png", asteroides=3):
    img = np.zeros((400, 400, 3), dtype="uint8")
    for _ in range(asteroides):
        x, y = np.random.randint(50, 350, size=2)
        r = np.random.randint(10, 50)
        color = (200, 200, 200)
        cv2.circle(img, (x, y), r, color, -1)
    return img

if __name__ == "__main__":
    os.makedirs("demo_images", exist_ok=True)
    for i in range(3):
        img = generar_imagen_demo(f"demo_{i}.png", asteroides=np.random.randint(1, 5))
        cv2.imwrite(f"demo_images/demo_{i}.png", img)
    print("Imágenes demo creadas en la carpeta demo_images/")
