import streamlit as st
import cv2
import numpy as np
from detection import detectar_asteroides
from physics import calcular_fisica
from utils import cargar_imagen
import os

st.set_page_config(page_title="DEEM-IA", layout="wide")

st.title("DEEM-IA: Demo de Detección y Estrategias de Mitigación de Asteroides")
st.markdown("App educativa para detección de asteroides en imágenes y cálculo de posibles estrategias.")

# --- Imagen de entrada ---
st.header("1) Usa imagen demo o carga la tuya")
col1, col2 = st.columns(2)

with col1:
    if st.button("Generar imágenes demo"):
        os.system("python generate_demo_images.py")
    demo_files = [f for f in os.listdir("demo_images") if f.endswith(".png")] if os.path.exists("demo_images") else []
    if demo_files:
        selected = st.selectbox("Elige una imagen demo:", demo_files)
        img_path = os.path.join("demo_images", selected)
        imagen = cv2.imread(img_path)
        st.image(imagen[:, :, ::-1], caption="Imagen seleccionada", use_container_width=True)
    else:
        imagen = None

with col2:
    uploaded_file = st.file_uploader("O sube una imagen", type=["jpg", "png"])
    if uploaded_file is not None:
        imagen = cargar_imagen(uploaded_file)
        st.image(imagen[:, :, ::-1], caption="Imagen subida", use_container_width=True)

# --- Procesamiento ---
st.header("2) Detección automática (simulada con OpenCV)")
if imagen is not None:
    resultados = detectar_asteroides(imagen)
    if resultados:
        for i, res in enumerate(resultados):
            diam_px = res["diametro_px"]

            # Conversión píxeles -> metros (ejemplo simplificado)
            escala = 5  # 1 píxel = 5 m
            diam_m = diam_px * escala

            fisica = calcular_fisica(diam_m)

            st.subheader(f"Asteroide {i+1}")
            st.write(f"Diámetro estimado: {diam_m:.1f} m")
            st.write(f"Energía estimada: {fisica['energia_j']/1e12:.2f} Terajoules")
            st.write(f"Nivel de riesgo: {fisica['color']} {fisica['riesgo']}")
            st.write("**Posibles estrategias de mitigación:**")
            for e in fisica["estrategias"]:
                st.write(f"- {e}")
    else:
        st.warning("No se detectaron objetos similares a asteroides.")
else:
    st.info("Sube o selecciona una imagen para comenzar.")

# --- Q&A educativo ---
st.header("3) Demo Q&A para niños")
pregunta = st.text_input("Haz una pregunta sobre asteroides:")
if pregunta:
    if "pequeño" in pregunta.lower():
        st.write("Un asteroide pequeño normalmente se quema en la atmósfera.")
    elif "grande" in pregunta.lower():
        st.write("Un asteroide grande puede causar daños serios.  Necesitamos estrategias como desvío o explosión controlada.")
    else:
        st.write("Los asteroides son rocas que viajan por el espacio. Según su tamaño, el riesgo cambia.")
