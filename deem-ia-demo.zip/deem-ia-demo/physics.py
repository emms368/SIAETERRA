import math

def calcular_fisica(diametro_m, velocidad_kms=20):
    """
    Calcula masa, energía y estrategias de mitigación según el diámetro.
    """
    densidad = 3000  # kg/m³ (asteroide rocoso típico)
    radio = diametro_m / 2
    volumen = (4/3) * math.pi * (radio ** 3)
    masa = densidad * volumen
    velocidad_ms = velocidad_kms * 1000
    energia = 0.5 * masa * (velocidad_ms ** 2)

    # Clasificación de riesgo y mitigación
    if diametro_m < 20:
        riesgo = "Bajo (se desintegra en la atmósfera)"
        estrategias = ["Monitoreo", "Evacuación local si es necesario"]
        color = "🟢"
    elif 20 <= diametro_m < 140:
        riesgo = "Medio (daños regionales posibles)"
        estrategias = [
            "Impactador cinético",
            "Explosión nuclear cercana",
            "Remolcador gravitacional si hay tiempo"
        ]
        color = "🟡"
    else:
        riesgo = "Alto (potencialmente catastrófico)"
        estrategias = [
            "Explosión nuclear controlada",
            "Remolcador gravitacional prolongado",
            "Plan internacional de evacuación global"
        ]
        color = "🔴"

    return {
        "masa_kg": masa,
        "energia_j": energia,
        "riesgo": riesgo,
        "estrategias": estrategias,
        "color": color
    }
