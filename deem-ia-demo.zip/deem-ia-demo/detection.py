import cv2
import numpy as np

def detectar_asteroides(imagen):
    """
    Detecta posibles asteroides en una imagen con OpenCV (simulación).
    Retorna lista de bounding boxes y diámetros estimados en píxeles.
    """
    gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gris, (5,5), 0)

    # Detección de círculos simulados (asteroides)
    circulos = cv2.HoughCircles(
        blur,
        cv2.HOUGH_GRADIENT,
        dp=1.2,
        minDist=30,
        param1=50,
        param2=30,
        minRadius=5,
        maxRadius=60
    )

    resultados = []
    if circulos is not None:
        circulos = np.round(circulos[0, :]).astype("int")
        for (x, y, r) in circulos:
            bbox = (x-r, y-r, x+r, y+r)
            resultados.append({
                "bbox": bbox,
                "diametro_px": r * 2
            })
    return resultados
