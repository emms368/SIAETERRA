from PIL import Image
import numpy as np
import cv2

def cargar_imagen(uploaded_file):
    """
    Carga una imagen en formato OpenCV desde un archivo subido.
    """
    imagen = Image.open(uploaded_file).convert("RGB")
    return cv2.cvtColor(np.array(imagen), cv2.COLOR_RGB2BGR)
